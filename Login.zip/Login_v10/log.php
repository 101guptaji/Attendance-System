<?php
$conn = new mysqli("localhost", "root", "");  // This should be changed to IIITN's server configuration
//$sql = "CREATE DATABASE attendanceSys;";   already created
//$conn->query($sql
  // echo "DB created";
// else {
//   echo "DB Already Created";
// }
// define variables and set to empty values
$username = $pass = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $username = test_input($_POST["username"]);
  $pass = test_input($_POST["pass"]);
  echo $username;
  echo $pass;
  // check pass from database fetched value and echo "logged in" if matched, else display error message
}

function test_input($data) {  // Security check function to prevent database from hacking
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>

//$conn=new mysqli("localhost", "root", "", "attendanceSys");
//$sql = "CREATE TABLE t1 (
//  id1 INT(5) UNSIGNED,
//  nm1 varchar(50)
//)";
//$conn->query($sql);
//$sql = "CREATE TABLE t2 (
//  id2 INT(5) UNSIGNED,
//  nm2 varchar(50)
//)";
//$conn->query($sql);
//$sql = "CREATE TABLE t3 (
//  id3 INT(5) UNSIGNED,
//  nm3 varchar(50)
//)";
//$conn->query($sql);
//$sql = "CREATE TABLE t4 (
//  id4 INT(5) UNSIGNED,
//  nm4 varchar(50)
//)";
//$conn->query($sql);
//$sql = "CREATE TABLE t5 (
//  id5 INT(5) UNSIGNED,
//  nm5 varchar(50)
//)";
$conn->query($sql);
$conn->close();
?>
